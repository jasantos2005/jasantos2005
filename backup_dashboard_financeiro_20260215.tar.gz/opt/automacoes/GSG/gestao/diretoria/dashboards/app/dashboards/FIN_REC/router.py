from fastapi import APIRouter, HTTPException
from app.dashboards.FIN_REC.service import FinanceiroService

router = APIRouter()
service = FinanceiroService()

@router.get("/resumo")
async def get_receber_resumo(inicio: str = "", fim: str = ""):
    try:
        data = service.get_resumo(inicio, fim)
        if not data:
            return {"status": "success", "data": {}}
        return {"status": "success", "data": data}
    except Exception as e:
        print(f"Erro no Router Receber: {e}")
        raise HTTPException(status_code=500, detail=str(e))
