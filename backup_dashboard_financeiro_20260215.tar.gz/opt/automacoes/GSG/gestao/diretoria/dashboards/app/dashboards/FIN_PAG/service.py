import mysql.connector
from app.config import settings
import os

class PagarService:
    def __init__(self):
        self.config = {
            'host': settings.DB_HOST, 'user': settings.DB_USER,
            'password': settings.DB_PASS, 'database': settings.DB_NAME, 'port': settings.DB_PORT
        }
        self.path_sql = "/opt/automacoes/GSG/gestao/diretoria/dashboards/app/dashboards/FIN_PAG/queries.sql"

    def _execute(self, query_name, inicio="", fim=""):
        try:
            with open(self.path_sql, 'r') as f:
                queries = f.read().split('-- @')
            
            sql = next((q.replace(query_name, '').strip() for q in queries if q.strip().startswith(query_name)), "")
            
            if not sql:
                return {"total": 0}

            # Substituição dinâmica das datas nas queries SQL
            if inicio and fim:
                sql = sql.replace(':inicio', f"'{inicio}'").replace(':fim', f"'{fim}'")
            
            conn = mysql.connector.connect(**self.config)
            cursor = conn.cursor(dictionary=True)
            cursor.execute(sql)
            result = cursor.fetchone()
            while cursor.nextset(): pass
            cursor.close()
            conn.close()
            
            return result if result else {"total": 0}
        except Exception as e:
            print(f"Erro no Service Pagar ({query_name}): {e}")
            return {"total": 0}

    def get_resumo_pagar(self, inicio="", fim=""):
        """Retorna o dicionário com as chaves exatas que o seu HTML procura"""
        return {
            "passivo_total": self._execute('QUERY_PASSIVO_TOTAL', inicio, fim),
            "passivo_vencido": self._execute('QUERY_PASSIVO_VENCIDO', inicio, fim),
            "pressao_30d": self._execute('QUERY_PRESSAO_30D', inicio, fim),
            "projecao_90d": self._execute('QUERY_PROJECAO_90D', inicio, fim),
            "sustentabilidade": self._execute('QUERY_SUSTENTABILIDADE', inicio, fim)
        }
