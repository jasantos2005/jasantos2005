from fastapi import APIRouter, Query
from app.dashboards.FIN_PAG.service import PagarService

router = APIRouter()
service = PagarService()

@router.get("/resumo")
async def get_pagar_resumo(
    inicio: str = Query("", description="Data de início do filtro"),
    fim: str = Query("", description="Data de fim do filtro")
):
    # Agora a rota recebe as datas e envia para o PagarService processar no SQL
    return {
        "status": "success", 
        "data": service.get_resumo_pagar(inicio=inicio, fim=fim)
    }
