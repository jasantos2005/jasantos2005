import mysql.connector
from app.config import settings
import os

class FinanceiroService:
    def __init__(self):
        self.config = {
            'host': settings.DB_HOST, 'user': settings.DB_USER,
            'password': settings.DB_PASS, 'database': settings.DB_NAME, 'port': settings.DB_PORT
        }
        # Mantendo o caminho fixo para o Receber conforme solicitado
        self.path_sql = "/opt/automacoes/GSG/gestao/diretoria/dashboards/app/dashboards/FIN_REC/queries.sql"

    def _execute(self, query_name, inicio="", fim=""):
        try:
            with open(self.path_sql, 'r') as f:
                queries = f.read().split('-- @')
            
            sql = next((q.replace(query_name, '').strip() for q in queries if q.strip().startswith(query_name)), "")
            
            # Adicionando tratamento básico para as datas nas queries se necessário
            if inicio and fim:
                sql = sql.replace(':inicio', f"'{inicio}'").replace(':fim', f"'{fim}'")
            
            conn = mysql.connector.connect(**self.config)
            cursor = conn.cursor(dictionary=True)
            cursor.execute(sql)
            result = cursor.fetchone()
            while cursor.nextset(): pass
            cursor.close()
            conn.close()
            return result if result else {}
        except Exception as e:
            print(f"Erro SQL {query_name}: {e}")
            return {}

    def get_resumo(self, inicio, fim):
        # Removidas as duplicidades do Pagar para não conflitar com outros serviços
        return {
            "recuperacao_mes_ant": self._execute('SQL_01', inicio, fim),
            "recuperacao_historica": self._execute('SQL_02', inicio, fim),
            "pagamento_prazo": self._execute('SQL_03', inicio, fim),
            "media_atraso": self._execute('SQL_04', inicio, fim),
            "arpu_caixa": self._execute('SQL_05', inicio, fim),
            "inadimplencia_mes": self._execute('SQL_06', inicio, fim),
            "inadimplencia_ano": self._execute('SQL_07', inicio, fim),
            "inadimplencia_fechada": self._execute('SQL_08', inicio, fim),
            "exposicao_mes": self._execute('SQL_09', inicio, fim),
            "exposicao_ano": self._execute('SQL_10', inicio, fim)
        }
